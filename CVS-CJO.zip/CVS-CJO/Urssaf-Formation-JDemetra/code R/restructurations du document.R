
library("dplyr")
library("tidyr")

cvae <- readxl::read_xlsx("CVS-CJO/Urssaf-Formation-JDemetra/Donnees/INT_CVAE_EFF_REG_H_serie.xlsx")


cvae_out <- cvae %>% 
  group_by(Date, flag_interim) %>% 
  summarise(
    EMA_somme = sum(EMA_somme, na.rm = TRUE), 
    rem001 = sum(rem001  , na.rm = TRUE), 
    rem017 = sum(rem017 , na.rm = TRUE), 
    rem018 = sum(rem018  , na.rm = TRUE), 
    volume_horaire = sum(volume_horaire, na.rm = TRUE)
    ) %>% 
  pivot_wider(names_from = flag_interim, values_from = c(EMA_somme,       rem001,     rem017,     rem018, volume_horaire)) %>% 
  mutate(Date = as.Date(Date))
  
write.csv(cvae_out, "cvae.csv")
